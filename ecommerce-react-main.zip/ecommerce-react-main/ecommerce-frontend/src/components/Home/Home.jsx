import React from "react";
import Hero from "../Hero/Hero";


const Home = () => {
  return (
    <div className="home-container">
    <Hero/>
    </div>
  );
};

export default Home;
